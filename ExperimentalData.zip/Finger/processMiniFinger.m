clear variables
fontname = 'Helvetica';
set(0,'DefaultAxesFontName',fontname,'DefaultTextFontName',fontname);
set(0,'DefaultAxesFontSize',12);
set(0,'DefaultLineLineWidth',1.2);

shell = csvread('shell3.csv');
noshell = csvread('noshell3.csv');

shell_zero = shell(1,1);
noshell_zero = noshell(1,1);

shell(:,1) = shell(:,1) - shell_zero;
noshell(:,1) = noshell(:,1) - noshell_zero;

shell = lowpass(shell,10,100);
noshell = lowpass(noshell,10,100);

fig = figure(1); clf; hold on; box on; grid on;
plot(shell(:,1),shell(:,2)/1e3,'-')
plot(noshell(:,1),noshell(:,2)/1e3,'-')

xlim([0 2.5]);
xlabel('Blocked Force (N)');
ylabel('Pressure (kPa)');
legend({'With Structural Cores', 'Without Structural Cores'},'location','SouthEast');

fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
print(fig,'Figures/FingerForceOutput','-depsc','-r300')
print(fig,'Figures/FingerForceOutput','-dpng','-r300')
