clear variables;
fontname = 'Helvetica';
set(0,'DefaultAxesFontName',fontname,'DefaultTextFontName',fontname);
set(0,'DefaultAxesFontSize',12);
set(0,'DefaultLineLineWidth',1.2);

weights = readtable('weights.xlsx','ReadRowNames',true);

fig = figure(1); clf; hold on; grid on; box on;
% bar([1, 2,2.5,3],[
bar([1, 3,4,5],[
    weights.average('hollow');
    weights.average(12:14)]);
% bar([4, 5,5.5,6],[
bar([7, 9,10,11],[
    weights.average('solid');
    weights.average(5:7)]);
% er = errorbar([1, 2,2.5,3, 4, 5,5.5,6],[
er = errorbar([1, 3,4,5, 7, 9,10,11],[
    weights.average('hollow');
    weights.average(12:14);
    weights.average('solid');
    weights.average(5:7)],[
    weights.std('hollow');
    weights.std(12:14);
    weights.std('solid');
    weights.std(5:7)]);
er.Color = [0 0 0];                            
er.LineStyle = 'none';
% xticks([1, 2,2.5,3, 4, 5,5.5,6]);
xticks([1, 3,4,5, 7, 9,10,11]);
xticklabels({'Hollow','Top','Side','Right','Solid','0.4 mm','0.5 mm','0.6 mm'});
xlabel('Casted Specimen Type');
ylabel('Specimen Weight (g)');
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
set(gca,'FontName','Helvetica','fontsize',8)
% print(fig,'Figures/WeightsCasted','-depsc','-r300')
% print(fig,'Figures/WeightsCasted','-dpng','-r300')


fig = figure(2); clf; hold on; grid on; box on;
bar([1,1.5,2],weights.average(9:11));
bar([3,3.5,4],weights.average(2:4));
er = errorbar([1,1.5,2, 3,3.5,4],[
    weights.average(9:11);
    weights.average(2:4)],[
    weights.std(9:11);
    weights.std(2:4)]);
er.Color = [0 0 0];                            
er.LineStyle = 'none';
xticks([1,1.5,2,3,3.5,4]);
xticklabels({'Top','Side','Right Angles','0.4 mm','0.5 mm','0.6 mm'});
xlabel('Specimen Core Type');
ylabel('Specimen Weight (g)');
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
set(gca,'FontName','Helvetica','fontsize',8)
% print(fig,'Figures/WeightsCores','-depsc','-r300')
% print(fig,'Figures/WeightsCores','-dpng','-r300')

    