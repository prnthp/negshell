clear variables
fontname = 'Helvetica';
set(0,'DefaultAxesFontName',fontname,'DefaultTextFontName',fontname);
set(0,'DefaultAxesFontSize',12);
set(0,'DefaultLineLineWidth',1);

global AREA;
AREA = pi*10e-3.^2; % Contact area of specimen

% files = dir('data');
% filenames = {files.name};
% for fileidx = 3:length(filenames)
%     check = readmatrix(char(strcat('data/',filenames(fileidx))));
%     check = rmmissing(check(:,1:end-1));
%     plot(check(:,4), check(:,5));
%     title(filenames(fileidx));
%     pause;
% end

% Stiffness of Solid Specimens, Force vs. Displacement

% [stress, strain] = get_mechanical_properties_solid('04-2.csv');
% [modulus, stress_linear, strain_linear] = get_elastic_modulus(stress, strain, 500, 1000);

% return;

% fig = figure(1); clf; hold on;
% [stress, strain, modulus1] = get_mechanical_properties_solid('04-2.csv');
% plot(strain, stress);
% [stress, strain, modulus2] = get_mechanical_properties_solid('05-2.csv');
% plot(strain, stress);
% [stress, strain, modulus3] = get_mechanical_properties_solid('06-3.csv');
% plot(strain, stress);
% [stress, strain, modulus4] = get_mechanical_properties_solid('solid-1.csv');
% plot(strain, stress);

fig = figure(1); clf; hold on; box on; grid on;
[stress, strain, modulus(1), mod_sd(1)] = average_mechanical_properties({'04-1.csv','04-2.csv','04-3.csv'},'solid');
plot(strain*100, stress/1e3);
[stress, strain, modulus(2), mod_sd(2)] = average_mechanical_properties({'05-1.csv','05-2.csv'},'solid');
plot(strain*100, stress/1e3);
[stress, strain, modulus(3), mod_sd(3)] = average_mechanical_properties({'06-1.csv','06-2.csv','06-3.csv'},'solid');
plot(strain*100, stress/1e3);
[stress, strain, modulus(4), mod_sd(4)] = average_mechanical_properties({'solid-1.csv','solid-2.csv','solid-3.csv'},'solid');
plot(strain*100, stress/1e3);

legend({'0.4 mm', '0.5 mm', '0.6 mm', 'Solid Silicone'},'location','NorthWest');
xlabel('Strain (%)');
ylabel('Sress (kPa)');
ylim([0, 200]);
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
% print(fig,'Figures/SolidStressStrainCurve','-depsc','-r300')
% print(fig,'Figures/SolidStressStrainCurve','-dpng','-r300')


fig = figure(4); clf; hold on; box on; grid on;
bar(1:4,modulus/1e6,'FaceColor',hex2rgb('8DC640'));
% bar(1,modulus(1)/1e6);
% bar(2,modulus(2)/1e6);
% bar(3,modulus(3)/1e6);
% bar(4,modulus(4)/1e6);
er = errorbar(1:4,modulus/1e6,mod_sd/1e6);    
er.Color = [0 0 0];                            
er.LineStyle = 'none';
xticks(1:4);
xticklabels({'0.4 mm', '0.5 mm', '0.6 mm', 'Solid Silicone'});
ylabel('E (MPa)');
xlabel('Structural Specimen Type');
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
% print(fig,'Figures/SolidElasticModulus','-depsc','-r300')
% print(fig,'Figures/SolidElasticModulus','-dpng','-r300')

% fig = figure(2); clf; hold on;
% [stress, strain, modulus1] = get_mechanical_properties_shell('topcrushed-1.csv');
% plot(strain, stress);
% [stress, strain, modulus2] = get_mechanical_properties_shell('sidecrushed-1.csv');
% plot(strain, stress);
% [stress, strain, modulus3] = get_mechanical_properties_shell('bothcrushed-1.csv');
% plot(strain, stress);
% [stress, strain, modulus4] = get_mechanical_properties_shell('hollow-1.csv');
% plot(strain, stress);
% [stress, strain] = get_mechanical_properties_solid('solid-1.csv');
% plot(strain, stress);

fig = figure(2); clf; hold on; box on; grid on;
[stress, strain, modulus(1), mod_sd(1)] = average_mechanical_properties({'topcrushed-1.csv','topcrushed-2.csv','topcrushed-3.csv'},'shell');
plot(strain*100, stress/1e3);
[stress, strain, modulus(2), mod_sd(2)] = average_mechanical_properties({'sidecrushed-1.csv','sidecrushed-2.csv','sidecrushed-3.csv'},'shell');
plot(strain*100, stress/1e3);
[stress, strain, modulus(3), mod_sd(3)] = average_mechanical_properties({'bothcrushed-1.csv','bothcrushed-2.csv','bothcrushed-3.csv'},'shell');
plot(strain*100, stress/1e3);
[stress, strain, modulus(4), mod_sd(4)] = average_mechanical_properties({'hollow-1.csv','hollow-2.csv','hollow-3.csv'},'shell');
plot(strain*100, stress/1e3);
[stress, strain] = average_mechanical_properties({'solid-1.csv','solid-2.csv','solid-3.csv'},'solid');
plot(strain*100, stress/1e3);

legend({'Top', 'Side', 'Right Angles', 'Hollow', 'Solid'},'location','SouthEast');
xlabel('Strain (%)');
ylabel('Sress (kPa)');
ylim([0, 45]);
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
% print(fig,'Figures/NegshellStressStrainCurve','-depsc','-r300')
% print(fig,'Figures/NegshellStressStrainCurve','-dpng','-r300')

fig = figure(5); clf; hold on; box on; grid on;
bar(1:4,modulus/1e3,'FaceColor',hex2rgb('D56027'));
er = errorbar(1:4,modulus/1e3,mod_sd/1e3);    
er.Color = [0 0 0];                            
er.LineStyle = 'none';
xticks(1:4);
xticklabels({'Top Perforation', 'Side Perfortaion', 'Right Angles Perfortaion', 'Hollow Silicone'});
ylabel('E (kPa)');
xlabel('Negshell Specimen Type');
ylim([0 200]);
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
% print(fig,'Figures/NegshellElasticModulus','-depsc','-r300')
% print(fig,'Figures/NegshellElasticModulus','-dpng','-r300')

fig = figure(99); hold on;
h = plot(1:10,1:10,1:10,2:11,1:10,2:11);
c = get(h,'Color');
close(fig);

fig = figure(3); clf; hold on; box on; grid on;
[force, ~, cmd_displacement] = get_breaking_properties('topside-1.csv');
plot(cmd_displacement, force, 'Color', c{1});
[force, ~, cmd_displacement] = get_breaking_properties('sideside-1.csv');
plot(cmd_displacement, force, 'Color', c{2});
[force, ~, cmd_displacement]= get_breaking_properties('bothside-1.csv');
plot(cmd_displacement, force, 'Color', c{3});
[force, ~, cmd_displacement] = get_breaking_properties('topside-2.csv');
plot(cmd_displacement, force, 'Color', c{1});
[force, ~, cmd_displacement] = get_breaking_properties('topside-3.csv');
plot(cmd_displacement, force, ':' , 'Color', c{1});
[force, ~, cmd_displacement] = get_breaking_properties('sideside-2.csv');
plot(cmd_displacement, force, 'Color', c{2});
[force, ~, cmd_displacement] = get_breaking_properties('sideside-3.csv');
plot(cmd_displacement, force, 'Color', c{2});
[force, ~, cmd_displacement]= get_breaking_properties('bothside-2.csv');
plot(cmd_displacement, force, 'Color', c{3});
[force, ~, cmd_displacement]= get_breaking_properties('bothside-3.csv');
plot(cmd_displacement, force, 'Color', c{3});

legend({'Top', 'Side', 'Right Angles'});
ylabel('Force (N)');
xlabel('Commanded Displacement (mm)');
xlim([0 6]);
ylim([0 45]);
fig.PaperUnits = 'inches';
fig.PaperPosition = [0 0 4 4];
set(gcf,'renderer','Painters')
print(fig,'Figures/NegshellBreakingForce','-depsc','-r300')
print(fig,'Figures/NegshellBreakingForce','-dpng','-r300')


function data = loaddata(filename)
    data = readmatrix(char(strcat('data/',filename)));
    data = rmmissing(data(:,1:end-1));
end

function [stress, strain, modulus, mod_sd] = average_mechanical_properties(filenames,mode)
    stress = [];
    strain = [];
    for fileidx = 1:length(filenames)
        if strcmp(mode,'solid')
            [stress(:,fileidx), strain(:,fileidx), modulus(:,fileidx)] = get_mechanical_properties_solid(char(filenames(fileidx)));
        else
            [stress(:,fileidx), strain(:,fileidx), modulus(:,fileidx)] = get_mechanical_properties_shell(char(filenames(fileidx)));
        end
    end
    stress = mean(stress,2);
    strain = mean(strain,2);
    
    stress = mean(reshape(stress,2000,5),2);
    strain = mean(reshape(strain,2000,5),2);
    
    mod_sd = std(modulus);
    modulus = mean(modulus);
end

function [stress, strain, modulus] = get_mechanical_properties_solid(filename)
    global AREA
    temp_data = loaddata(filename);
    data = temp_data(4201:4200+10000,:); % 4.2 sec to 0.5 Hz 5 cycles, 1 mm + 4.2 sec
    strain = -(data(:,4) - data(1,4))/15; % Strain
    stress = -data(:,5)/AREA;
    
    [modulus, ~, ~] = get_elastic_modulus(stress, strain, 500, 1000);
end

function [stress, strain, modulus] = get_mechanical_properties_shell(filename)
    global AREA
    temp_data = loaddata(filename);
    data = temp_data(1001:1000+10000,:); % 1 sec to 0.5 Hz 5 cycles, 4 mm + 1 sec
    strain = -(data(:,4) - data(1,4))/15; % Strain
    stress = -data(:,5)/AREA; % Pa
    
    [modulus, ~, ~] = get_elastic_modulus(stress, strain, 500, 1000);
end

function [force, displacement, cmd_displacement] = get_breaking_properties(filename)
    temp_data = loaddata(filename);
    data = temp_data(1:4300+8000,:); % 4.3 sec to 4 mm / 0.25 mm/s  + 4.3 sec
    displacement = -(data(:,4) - data(1,4)); % mm
    force = -data(:,5); % N
    force = lowpass(force,20,1000);
    cmd_displacement = [linspace(0,4.3,4300), linspace(4.3+1/2000,6.3,8000)];
    % Subsampling for plot
    force = force(floor(linspace(1,length(force),1230)));
    cmd_displacement = cmd_displacement(floor(linspace(1,length(cmd_displacement),1230)));
end

function [modulus, stress_linear, strain_linear] = get_elastic_modulus(stress,strain,offset,duration)
    % Find slope given region
    shift = [0 1 2 3 4]*2000;
    region = offset:offset+duration;
    indices = [region+shift(1), region+shift(2), region+shift(3), region+shift(4), region+shift(5)];
    
    stress_linear = stress(indices,:);
    strain_linear = strain(indices,:);
    fit_coeff = glmfit(strain_linear,stress_linear);
    modulus = fit_coeff(2);
end